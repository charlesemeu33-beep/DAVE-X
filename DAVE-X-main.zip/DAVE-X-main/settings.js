const settings = {
  packname: '',
  author: 'Davex Tech',
  botName: "DAVE-X",
  botOwner: 'Dave',
  ownerNumber: '254104260236',
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 5, 
  storeWriteInterval: 30000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "4.0.0",
  updateZipUrl: "https://github.com/Davex-254/DAVE-X/archive/refs/heads/main.zip",
};

module.exports = settings;
